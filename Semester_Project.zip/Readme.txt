 NAME:AUGUSTA ODONKOR.
 INDEX NUMBER:UEB3257922.
 CLASS:I.T. A
 PROJECT DESCRIPTION: VODAFONE CASH CLONE.

 The Vodafone Cash Clone Mini Console Application is a C++ project that aims to
 simulate the core functionalities of a mobile financial service similar to Vodafone
 Cash. This project provides a simplified version of the Vodafone Cash platform,
 allowing users to perform basic financial transactions through a console
 interface. Users can send and receive money, check their balance, buy airtime,
 and handle other essential mobile money operations.
 The application must include user registration and login, balance inquiry, money
 transfer, receipt of money, airtime purchase, transaction history viewing, PIN
 change, simulated network interaction, error handling, and an exit option for
 basic mobile financial transactions simulation.
 Implementation: The implementation of the project will involve using C++,
 making use of functions, data structures, and conditional statements. Storage of
 data can be organized through constructs such as arrays or linked lists, while
 user authentication, transaction history, and account balances can be emulated
 by employing suitable data structures.